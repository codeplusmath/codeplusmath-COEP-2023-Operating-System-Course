#include <stdio.h>
int main() {
	char buf[128];
	scanf("%s", buf);
	printf("%s\n", buf);
	return 0;
}

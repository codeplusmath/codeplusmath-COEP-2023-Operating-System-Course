#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char * argv[]){
	int i,j, fd;
	char data[64];

	if(argc<1){
		return 1;
	}
	
	else{
		if(access(argv[1], F_OK ) == 0){
    			fd = open(argv[1], O_RDWR);
			if(fd==-1)  return 1;
			lseek(fd, 5, SEEK_SET);
			read(fd, data, 6);
			printf("%s", data);
			return 0;
		}
		else{
			return 1;
		}
	}
}


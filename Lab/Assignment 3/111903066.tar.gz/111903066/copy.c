#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h> 

int main(int argc, char * argv[]){
	int fd1, fd2;
	char buff[1024];
	long int n;
	if(argc<1){
		return 1;
	}
	else{
		if(((fd1 = open(argv[1], O_RDONLY)) == -1) || ((fd2 = open(argv[2], O_CREAT|O_WRONLY|O_TRUNC, 0700)) == -1)){
			return 1;
		}
		while((n = read(fd1, buff, 1024)) > 0){
			if(write(fd2, buff, n) != n){
				return 1;
			}
		}
		close(fd1);
		close(fd2);
		return 0;
	}

}


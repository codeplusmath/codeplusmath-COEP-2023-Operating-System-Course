#!/bin/bash

filename='new20.txt'
path='/tmp/'

./read100 $filename


if [ $? -eq 0 ]
then
	if [ $( ls -lah  $path$filename | cut -d ' ' -f 5 ) -eq 100 ]
	then
		bytedata='EAD628C73F5C3CC1A31F46F3D484EE44862BEDFBF6CD61562B5F18E9272C5490B77DA8356DA6CA9227EDB2811F6B892BC0A4'
		if [ "$bytedata" == "$( cat $path$filename )" ]
		then
			echo "read100 pass"
		else
			echo "read100 fail"
		fi
	else
		echo "read100 fail"
	fi
else
	echo "read100 fail"
fi


filename='/tmp/new20.txt'
output=$(./read510 $filename)

if [ $? -eq 0 ]
then
	realdata=$(head -c +11 $filename | tail -c +6)		
	if [ "$output" == "$realdata" ]
	then
		echo "read510 pass"
	else
		echo "read510 fail"
	fi
else
	echo "read510 fail"
fi


filename='/tmp/new20.txt'

./write10end $filename

if [ $? -eq 0 ]
then
	if [ $( ls -lah  $filename | cut -d ' ' -f 5 ) -eq 111 ]
	then
		bytedata="21D243279F"
		data="$(cat $filename)"
		if [[ "$data" == *$diffdata ]]
		then
			echo "write10end pass"
		else
			echo "write10end fail"
		fi
	else
		echo "write10end fail"
	fi
else
	echo "write10 fail"
fi


filename='/tmp/new20.txt'
newfilename='/tmp/new21.txt'

./copy $filename $newfilename

if [ $? -eq 0 ]
then
	diff $filename $newfilename 
	if [ $? -eq 0 ]
	then
		echo "copy pass"
	else
		echo "copy fail"
	fi
else
	echo "copy fail"
fi



filename='/tmp/new21.txt'
newname='/tmp/new22.txt'

cp $filename '/tmp/renametmp.txt'
./rename $filename $newname

if [ $? -eq 0 ]
then
	diff $newname '/tmp/renametmp.txt' 
	if [ $? -eq 0 ]
	then
		echo "rename pass"
	else
		echo "rename fail"
	fi
	rm '/tmp/renametmp.txt'
else
	echo "rename fail"
fi


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char * argv[]){
	int sz, fd;
	char path[50] = "/tmp/";
	char data[] = "EAD628C73F5C3CC1A31F46F3D484EE44862BEDFBF6CD61562B5F18E9272C5490B77DA8356DA6CA9227EDB2811F6B892BC0A4";
	if(argc<1){
		strcat(path, "tmp.txt");
	}
	else{
		strcat(path, argv[1]);
		if(access( path, F_OK ) == 0 ) {
    			if(remove(path)!=0) return 1;
		}
		
	}
	
	fd = open(path, O_WRONLY | O_CREAT );
	if(fd <= 0){
		return 1;
	}

	sz = write(fd, data, 100);
	close(fd);
	return 0;
}


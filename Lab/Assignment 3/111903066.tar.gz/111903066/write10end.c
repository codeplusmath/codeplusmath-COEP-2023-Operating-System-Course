#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char * argv[]){
	int fd, tmp;
	char data[] = "21D243279F";
	if(argc<1){
		return 1;
	}
	else{
		if(access(argv[1], F_OK ) == 0 ) {
    			fd = open(argv[1], O_RDWR);
			if(fd == -1) return 1;
			lseek(fd, 0, SEEK_END);
			write(fd, data, sizeof(data));
			close(fd);
			return 0;
		}
		
		return 1;
	}
}

